/*
defines all the methods for interfacing with the database
 */
package com.algonquincollege.fileManager.database;

/**
 *
 * @author Byzantian
 */
public class DBInterface {
    
}
