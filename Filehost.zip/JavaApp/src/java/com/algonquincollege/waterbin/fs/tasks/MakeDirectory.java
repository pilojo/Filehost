package com.algonquincollege.waterbin.fs.tasks;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 *
 * @author Devon St. John
 */
public class MakeDirectory extends FileSystemTask{

    private final String path;
    
    
    public MakeDirectory(String path){
        this.path = path;
        
        System.out.println("Make Directory Task: Launched to Aggregator");
    }
    
    @Override
    public void run() {
        System.out.println("Make Directory Task: " + path + " | Going Live");
        try{
            Files.createDirectory(Paths.get(root, path));
            success = true;
        } catch (IOException ex) {
            System.err.println("Make Directory Task Failed: " + path);
        }
        System.out.println("Make Directory Task: Completed");
        
    }
    
    @Override
    public boolean getSuccess(){
        return Files.exists(Paths.get(root, path));
    }
    
}
