import { Component } from '@angular/core';

@Component({
  selector: 'app-user-search',
  templateUrl: './fileSearch.component.html'
})
export class FileSearchComponent {

}
